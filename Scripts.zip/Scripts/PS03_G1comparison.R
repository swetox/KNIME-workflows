########## Libraries #########
library(ggplot2)

mytheme = base_size = 14
mytheme <- theme(
  text =					element_text(family = "Arial"),			
  title =					element_text(family = "Arial"),			
  
  axis.line =         	element_line(colour = "black"),
  axis.text.x =       	element_text(size = base_size * 0.8 , face = "bold", lineheight = 0.9, colour = "black", vjust = 1),
  axis.text.y =       	element_text(size = base_size * 0.8, face = "bold", lineheight = 0.9, colour = "black", hjust = 1),
  axis.ticks =        	element_line(colour = "black"),
  axis.title.x =      	element_text(size = base_size, face = "bold", vjust = 0.5),
  axis.title.y =      	element_text(size = base_size, face = "bold", angle = 90, vjust = 0.5),
  axis.ticks.length = 	unit(0.15, "cm"),
  axis.ticks.margin = 	unit(0.1, "cm"),
  
  legend.background = element_rect(colour=NA), 
  legend.key =        element_rect(fill = NA, colour = "black", size = 0.25),
  legend.key.size =   unit(1.2, "lines"),
  legend.text =       element_text(size = base_size * 0.8),
  legend.title =      element_text(size = base_size * 0.8, face = "bold", hjust = 0),
  legend.position =   "bottom",
  
  panel.background =  element_rect(fill = NA, colour = NA, size = 0.25), 
  panel.border =      element_blank(),
  panel.grid.major =  element_line(colour = NA, size = 0.05),
  panel.grid.minor =  element_line(colour = NA, size = 0.05),
  panel.margin =      unit(0.25, "lines"),
  
  strip.background =  element_rect(fill = NA, colour = NA), 
  strip.text.x =      element_text(colour = "black", face = "bold", size = base_size),
  strip.text.y =      element_text(colour = "black", face = "bold", size = base_size, angle = -90),
  
  plot.background =   element_rect(colour = NA, fill = "white"),
  plot.title =        element_text(size = base_size * 1.2, face = "bold"),
  plot.margin =       unit(c(1, 1, 0.5, 0.5), "lines")
)
################################
generation = unique(knime.in$"Generation")

######### Change levels #########
if(grepl("RF", generation) == TRUE){
  combolevels = c("Molecular descriptors (MD)", "Fingerprint (FP)", "Both (ALL)")
  parameterlevels <- c("R[OOB]^2", "RMSE[OOB]")
  output = "OOB"
} else{
  combolevels = c("Molecular descriptors (MD)")
  parameterlevels  = c("R[CV]^2", "RMSE[CV]")
  output ="CV"
}

levels(knime.in$Combo)	<- combolevels
levels(knime.in$Transformation) <- c("Log", "Un")

levels(knime.in$Parameter) <- parameterlevels

######## Plotting ################
pALL <- ggplot(knime.in, aes(x = Tissue, y = Value, color = Combo, fill = Combo)) + mytheme + 
  geom_col(position = "dodge") + 
  scale_color_grey() +
  scale_fill_grey() +
  scale_y_continuous(expand= c(0,0)) +
  theme(	legend.text = element_text(size =10),
         axis.title.y = element_blank(), 
         axis.text.x = element_text(size = 8, angle = 45, hjust = 1, vjust = 1), 
         legend.title = element_blank(), 
         axis.title.x = element_blank(), 
         strip.text.x = element_text(size = 6, face = "bold", margin = margin(t=1, r =1, b = 1, l = 1, unit ="pt")),
         strip.text.y = element_text(size = 12, face = "bold"), 
         strip.placement.y = "outside",
         legend.key.size = unit(10, "pt")) +
  facet_grid(Parameter ~ Data + Transformation, 
             scales = "free", 
             switch = "both", 
             space = "free_x", 
             labeller = labeller(Parameter = label_parsed))

levels(knime.in$Transformation) <- c("Log-transformed", "Untransformed")

pMD <- ggplot(subset(knime.in, Combo == "Molecular descriptors (MD)"), aes(x = Tissue, y = Value, color = Transformation, fill = Transformation)) + mytheme + 
  geom_col(position = "dodge") + 
  scale_color_grey() +
  scale_fill_grey() +
  scale_y_continuous(expand= c(0,0)) +
  theme(	legend.text = element_text(size =10),
         axis.title.y = element_blank(), 
         axis.text.x = element_text(size = 8, angle = 45, hjust = 1, vjust = 1), 
         legend.title = element_blank(), 
         axis.title.x = element_blank(), 
         strip.text.x = element_text(size = 10, face = "bold", margin = margin(t=2, r =1, b = 1, l = 1, unit ="pt")),
         strip.text.y = element_text(size = 12, face = "bold"), 
         strip.placement.y = "outside",
         legend.key.size = unit(10, "pt")) +
  facet_grid(Parameter ~ Data, 
             scales = "free", 
             switch = "both", 
             space = "free_x", 
             labeller = labeller(Parameter = label_parsed))
pMD
pALL
######## Saving plot ##########
folder 	= knime.flow.in[["evaluationplotfolder"]]
nameMD = paste(generation, "_R2absRMSE_MD_", output, ".tiff", sep = "") 
nameALL = paste(generation, "_R2absRMSE_all_",output, ".tiff", sep = "") 

ggsave(plot = pALL, filename = nameALL, path = folder, device = "tiff", dpi = 300, width = 6.5, height = 4.5, unit = "in")
ggsave(plot = pMD, filename = nameMD, path = folder, device = "tiff", dpi = 300, width = 6.5, height = 4.5, unit = "in")
