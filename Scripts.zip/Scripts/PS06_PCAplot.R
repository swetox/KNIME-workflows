###############################
########## Libraries ###########
library(ggplot2)

mytheme = base_size = 14
mytheme <- theme(
  text =					element_text(family = "Arial"),			
  title =					element_text(family = "Arial"),			
  
  axis.line =         	element_line(colour = "black"),
  axis.text.x =       	element_text(size = base_size * 0.8 , face = "bold", lineheight = 0.9, colour = "black", vjust = 1),
  axis.text.y =       	element_text(size = base_size * 0.8, face = "bold", lineheight = 0.9, colour = "black", hjust = 1),
  axis.ticks =        	element_line(colour = "black"),
  axis.title.x =      	element_text(size = base_size, face = "bold", vjust = 0.5),
  axis.title.y =      	element_text(size = base_size, face = "bold", angle = 90, vjust = 0.5),
  axis.ticks.length = 	unit(0.15, "cm"),
  axis.ticks.margin = 	unit(0.1, "cm"),
  
  legend.background = element_rect(colour=NA), 
  legend.key =        element_rect(fill = NA, colour = "black", size = 0.25),
  legend.key.size =   unit(1.2, "lines"),
  legend.text =       element_text(size = base_size * 0.8),
  legend.title =      element_text(size = base_size * 0.8, face = "bold", hjust = 0),
  legend.position =   "bottom",
  
  panel.background =  element_rect(fill = NA, colour = NA, size = 0.25), 
  panel.border =      element_blank(),
  panel.grid.major =  element_line(colour = NA, size = 0.05),
  panel.grid.minor =  element_line(colour = NA, size = 0.05),
  panel.margin =      unit(0.25, "lines"),
  
  strip.background =  element_rect(fill = NA, colour = NA), 
  strip.text.x =      element_text(colour = "black", face = "bold", size = base_size),
  strip.text.y =      element_text(colour = "black", face = "bold", size = base_size, angle = -90),
  
  plot.background =   element_rect(colour = NA, fill = "white"),
  plot.title =        element_text(size = base_size * 1.2, face = "bold"),
  plot.margin =       unit(c(1, 1, 0.5, 0.5), "lines")
)
####################################################
########## Boundaries and colours and sizes ########
dimensions = paste("d = ", unique(knime.in$"Dimensions")[1], sep ="")

max = ceiling(max(knime.in$"PCA dimension 0", knime.in$"PCA dimension 1"))
min = floor(min(knime.in$"PCA dimension 0", knime.in$"PCA dimension 1"))
lims = c(min, max)

size = 3
pshape = c(22, 23, 24, 25, 21)
pcol = c("black", "black", "black", "black", "grey20")
pfill = c("black", "black", "black", "black", NA) 
lcol = "grey"
lwd = 0.8
##############################
colnames(knime.in) <- c("Compound", "PCA0", "PCA1", "Dimensions", "PC")

ggplot(knime.in, aes(x = PCA0, y = PCA1, color = Compound, shape = Compound, fill = Compound )) + mytheme +
  geom_point(size = size) +
  scale_shape_manual(values = pshape) +
  scale_fill_manual(values = pfill) +
  scale_colour_manual(values = pcol)+
  scale_x_continuous(limits = lims, expand = c(0,0))+
  scale_y_continuous(limits = lims, expand = c(0,0))+ 
  theme(legend.title = element_blank(), legend.position = c(0.15, 0.8)) + 
  annotate("text", x = (lims[2]*0.8), y = (lims[2]*0.8), label = dimensions)


######### Saving plot #############
pc = knime.flow.in[["PC"]]
combo = knime.flow.in[["Combo"]]
generation = knime.flow.in[["Generation"]]
path = knime.flow.in[["plotfolder"]]
name = paste(generation, "_", pc, "_", combo, "_PCA.tiff", sep = "") 

ggsave(filename = name, path = path, device = "tiff", dpi = 300, width = 6.5, height = 4.5, unit = "in")


