###############################
########## Libraries ###########
library(ggplot2)

mytheme = base_size = 14
mytheme <- theme(
  text =					element_text(family = "Arial"),			
  title =					element_text(family = "Arial"),			
  
  axis.line =         	element_line(colour = "black"),
  axis.text.x =       	element_text(size = base_size * 0.8 , face = "bold", lineheight = 0.9, colour = "black", vjust = 1),
  axis.text.y =       	element_text(size = base_size * 0.8, face = "bold", lineheight = 0.9, colour = "black", hjust = 1),
  axis.ticks =        	element_line(colour = "black"),
  axis.title.x =      	element_text(size = base_size, face = "bold", vjust = 0.5),
  axis.title.y =      	element_text(size = base_size, face = "bold", angle = 90, vjust = 0.5),
  axis.ticks.length = 	unit(0.15, "cm"),
  axis.ticks.margin = 	unit(0.1, "cm"),
  
  legend.background = element_rect(colour=NA), 
  legend.key =        element_rect(fill = NA, colour = "black", size = 0.25),
  legend.key.size =   unit(1.2, "lines"),
  legend.text =       element_text(size = base_size * 0.8),
  legend.title =      element_text(size = base_size * 0.8, face = "bold", hjust = 0),
  legend.position =   "bottom",
  
  panel.background =  element_rect(fill = NA, colour = NA, size = 0.25), 
  panel.border =      element_blank(),
  panel.grid.major =  element_line(colour = NA, size = 0.05),
  panel.grid.minor =  element_line(colour = NA, size = 0.05),
  panel.margin =      unit(0.25, "lines"),
  
  strip.background =  element_rect(fill = NA, colour = NA), 
  strip.text.x =      element_text(colour = "black", face = "bold", size = base_size*0.8),
  strip.text.y =      element_text(colour = "black", face = "bold", size = base_size*0.8, angle = -90),
  
  plot.background =   element_rect(colour = NA, fill = "white"),
  plot.title =        element_text(size = base_size * 1.2, face = "bold", vjust  = 0.5, hjust = 0.5),
  plot.margin =       unit(c(1, 1, 0.5, 0.5), "lines")
)
####################################################
facetlist <- c()
for(i in 1:nrow(knime.in)){
  comp = knime.in$"Compartment"[i]
  if(comp == "Blood" | comp == "Cmixven"){
    facetlist[i] = "Blood"
  } else {
    facetlist[i] = "Exhaled air"
  }
}
knime.in$"facet" <- facetlist

########### Splitting in two dataframes ###########
df1 <- subset(knime.in, Compartment == "Cmixven" | Compartment == "Cexh")
df2 <- subset(knime.in, Compartment == "Blood" | Compartment == "Exhaled air")

########### Labels #################################

xlab = "Time (min)"
ylab = "Concentration (\u03BCM)"
scenario = gsub(",", ", ", knime.flow.in[["Scenario"]])
title = paste(scenario, " ppm", " (", knime.flow.in[["Source"]],")", sep = "")
#######################################################

ggplot(df1, aes(x = time, y = Concentration, group = Compartment)) + mytheme +
  geom_line(aes(colour = facet), cex = 1) +
  geom_ribbon(aes(x = time, ymin = Minimum, ymax = Maximum, colour = facet),fill = NA, linetype = 2, alpha = 0.15) +
  geom_errorbar(data = df2, width = 5, aes(x = time, ymin = Minimum, ymax = Maximum, colour = facet), alpha = 0.8) +
  geom_point(data = df2,aes(colour = facet), cex = 2) +
  labs(x = xlab, y = ylab, title = title) +
  scale_colour_manual(values = c("black", "grey30"), labels = c("PBTK", expression(italic(In~vivo)~data))) + 
  scale_y_continuous(trans = "log10", expand = c(0,0), breaks = c(0.001, 0.01, 0.1, 1.0, 10.0, 100.0, 1000.0))+
  scale_x_continuous(expand = c(0,0)) + 
  annotation_logticks(sides = "l", base = 10, color = "black", short = unit(0.2, "cm"), mid= unit(0.2, "cm")) +
  facet_wrap(~ facet, ncol =1) +
  guides(fill = guide_legend("none"), colour = guide_legend(label.hjust = 0, override.aes =list(shape= c(NA, 16), linetype = c(1,0), colour = c("black", "black")))) +
  theme(legend.title = element_blank(),
        legend.position = "top",
        strip.background = element_rect(fill = "grey90")) 


########### Saving plot ######################################
scenario = gsub(",", "", knime.flow.in[["Scenario"]])
folder = knime.flow.in[["plotfolder"]]
name = paste("TKvsEX_", scenario, ".tiff", sep ="")

ggsave(filename = name, path = folder, device = "tiff", dpi = 300, width = 6.5, height = 4.5, unit = "in")
