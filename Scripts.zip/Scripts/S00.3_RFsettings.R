##########################
treelist <- as.integer(seq(50, 1500, 25))
nodesizelist  <- as.integer(seq(2, 50, 1))
max= ceiling(50/round(sqrt(35)))
min= floor(2/round(sqrt(141)))

RelNodesize =  seq(0,11.6, 0.2)
length(RelNodesize)
length(treelist)

####### going out ########
knime.out <- data.frame(
  "TreeList" 	= as.character(treelist),
  "RelNodesize" 	= as.character(RelNodesize)#,
)

