######## Adding Suffix indicating HFCs are present #######
knime.in$PC = paste(knime.in$"PC", "A", sep="")
knime.out <- knime.in