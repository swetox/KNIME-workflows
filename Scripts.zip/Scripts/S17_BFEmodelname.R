######## Going out #######
knime.out <- knime.in[4:6]
knime.out$"modelname" <- paste(knime.flow.in[["PC"]], "_BFEmodel", sep="")