######## Identifying lowest error rate ####
i = match(min(knime.in$"Squarred Error"), knime.in$"Squarred Error")

####### Going out #####################
knime.out 		<- data.frame("n_descriptors" = knime.in$"Nr. of features"[i])
knime.out$"Limit" 	<- knime.in$"Squarred Error"[i]