########## Extracting descriptor names ######
descriptors = colnames(knime.in[,1:ncol(knime.in)])

####### Going out ##########
knime.out 	<- data.frame("Descriptors" = descriptors)
knime.out$"PC" <- knime.flow.in[["PC"]]
