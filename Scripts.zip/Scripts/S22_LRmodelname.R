######## Generating model name ######
knime.out <- knime.in[3]

##################
generation 	= knime.flow.in[["Generation"]]
pc 			= knime.flow.in[["PC"]]
name = paste(generation, "_", pc, "_MD", sep = "")

knime.out$"LRmodelname" <- name