############# Adding indicator #################
combo = "MD"
output = "CV"

############# Calculating n_descriptors ########
n_descriptors = ncol(knime.in)-3

######### Going out #############################
knime.out <- knime.in[,c(1:2, ncol(knime.in))]
colnames(knime.out)[1:3] <- c("Compound", "Observed", "Predicted")
knime.out$"Origin" 		<- "Training Data"
knime.out$"Combo" 		<- combo
knime.out$"Output"		<- output
knime.out$"n_descriptors"<- n_descriptors