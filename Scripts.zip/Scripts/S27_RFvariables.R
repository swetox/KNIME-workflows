####### Generation of need parameters #####
# Generation
generation = knime.flow.in[["Generation"]]

#random seed:
if(grepl("1", generation)){
  seed <- as.integer(sample(1:100000, 1))
} else {
  seed =  knime.flow.in[["Seed"]]
}

# nodesize:
relnodesize = as.numeric(knime.flow.in[["RelNodesize"]])
nodesize = as.integer(round(sqrt(nrow(knime.in)))*relnodesize)
if(nodesize < 6) {
  nodesize = as.integer(6)
}

# Trees:
trees <- as.integer(knime.flow.in[["Trees"]])

#childsize:
childsize = as.integer(nodesize*0.5)

# modelnames
MDmodel 	<- paste(generation, "_", knime.flow.in[["PC"]], "_MD", sep ="") 
FPmodel	<- paste(generation, "_", knime.flow.in[["PC"]], "_FP", sep ="") 
ALLmodel 	<- paste(generation, "_", knime.flow.in[["PC"]], "_ALL", sep ="") 

###### Going out ##########
knime.out 			<- data.frame("Seed" = seed)
knime.out$"Trees"		<- trees
knime.out$"nodesize" 	<- nodesize
knime.out$"childsize" 	<- childsize
knime.out$"MDmodel" 	<- MDmodel
knime.out$"FPmodel" 	<- FPmodel
knime.out$"ALLmodel" 	<- ALLmodel