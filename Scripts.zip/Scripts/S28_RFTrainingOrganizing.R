############# Adding indicator #################
column = knime.flow.in[["Column 0"]]

if(any(grepl("bitvector", names(knime.in))==TRUE) == TRUE){
  combo <- "ALL"
} else if(any(grepl("Fingerprint", column)==TRUE) == TRUE) {
  combo <- "FP"
} else {
  combo <- "MD"
}

############# Detecting if OOB or CV ###########
if(grepl(colnames(knime.in[ncol(knime.in)]), "model count") == TRUE){
  output = "OOB"
  nc = 7
} else{
  output = "CV"
  nc = 6}

############# Calculating n_descriptors ########

if(combo == "FP"){
  n_descriptors = 1024
} else {
  n_descriptors = ncol(knime.in)-nc
}

######### Going out #############################
knime.out <- knime.in[,c(1:2, (ncol(knime.in)-(nc-5)):(ncol(knime.in)-(nc-6)))]
colnames(knime.out)[1:4] <- c("Compound", "Observed", "Predicted", "Variance")
knime.out$"Origin" 		<- "Training Data"
knime.out$"Combo" 		<- combo
knime.out$"Output"		<- output
knime.out$"n_descriptors"<- n_descriptors