############################
nr2 = match(max(knime.in$"R2abs"), knime.in$"R2abs")
nrmse = match(min(knime.in$"RMSE"), knime.in$"RMSE")

if(nr2 == nrmse) {
  l = nr2
} else {
  l = c(nr2, rmse)
}

knime.out <- knime.in[l,]