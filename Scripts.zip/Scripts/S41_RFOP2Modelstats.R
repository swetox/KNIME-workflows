####### Statistical performance #######
training <- subset(knime.in, Origin == "Training Data")
observed = training$Observed
predicted = training$Predicted

n_compounds 	<- nrow(training)
n_descriptors 	<- unique(training$"n_descriptors")
combo 		<- unique(training$"Combo")
output 		<- unique(training$"Output")
r2_abs		<- 1-(sum((predicted-observed)^2)/(sum((observed-mean(observed))^2)))
rmse			<- sqrt(mean((observed-predicted)^2))

R2change		<- (r2_abs-knime.flow.in[["R2abs"]])/knime.flow.in[["R2abs"]]*100
RMSEchange 	<- (rmse-knime.flow.in[["RMSE"]])/knime.flow.in[["RMSE"]]*100

#### Going out #####
knime.out 				<- data.frame("PC" = knime.flow.in[["PC"]])
knime.out$"Generation"		<- knime.flow.in[["Generation"]]
knime.out$"Combo" 			<- combo
knime.out$"Output"			<- output
knime.out$"n_compounds"		<- n_compounds
knime.out$"n_descriptors" 	<- n_descriptors
knime.out$"R2abs"			<- r2_abs
knime.out$"RMSE"			<- rmse

knime.out$"R2Change"		<- R2change
knime.out$"RMSEChange"		<- RMSEchange
knime.out$"Descriptor"		<- knime.flow.in[["currentColumnName"]]

knime.out$"Seed" 			<- knime.flow.in[["Seed"]]
knime.out$"nodesize"		<- knime.flow.in[["nodesize"]]
knime.out$"RelNodesize"		<- knime.flow.in[["RelNodesize"]]
knime.out$"Trees"			<- knime.flow.in[["Trees"]]
