############
d = subset(knime.in, R2Change < 0 & RMSEChange > 0)
descriptors = d$Descriptor

###### Going out #######
knime.out <- d[, c(1, 11)]