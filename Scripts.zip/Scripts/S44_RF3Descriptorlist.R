######## Descriptors as columns ########
n = grep("Descriptor", colnames(knime.in))

descriptors = knime.in[,n]

############### Going out 
knime.out <- data.frame(matrix(NA, ncol = nrow(knime.in), nrow = 1))
colnames(knime.out) <- descriptors
knime.out <- cbind("Compound" = "c", "Value" = 1.2, knime.out)