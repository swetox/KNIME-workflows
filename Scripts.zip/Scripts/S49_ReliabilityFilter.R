########### Unique reliability #############
r = as.vector(unique(knime.in$"Reliability"))

knime.in$"Difference" <- (knime.in$"Domain Threshold"-knime.in$"Domain Value")
knime.in$"AverageDiff" <- mean(knime.in$"Domain Threshold"-knime.in$"Domain Value")

if(nrow(knime.in)<4){
  knime.out <- data.frame()
} else if(length(r)==2){
  knime.out <- data.frame()
} else if(grepl("unreliable", r)){
  knime.out <- data.frame()
} else {
  knime.out <- knime.in
}
