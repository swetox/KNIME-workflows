########### Highest R2 and lowest RMSE ###########

rR2 <- which(knime.in$"R2" == max(knime.in$"R2"))
rRMSE <- which(knime.in$"RMSEtrans" == min(knime.in$"RMSEtrans"))
rDiff <- which(knime.in$"AverageDiff" == max(knime.in$"AverageDiff"))

if(length(rDiff) > 4){	
  rDiff <- which(knime.in$"R2" == max(knime.in$"R2"[rDiff]))
}

if(length(unique(knime.in$"Reliability"))==1){
  ID <- "reliable"
} else {
  ID <- "unreliable"
}

if(ID == "reliable"){
  if(rR2 == rRMSE){
    l = rR2
  } else {
    l = c(rR2, rRMSE)
  }
} else {
  if(rR2 == rRMSE & rR2 == rDiff){
    l = rR2
  } else if(rR2 ==rRMSE & rR2 != rDiff){
    l = c(rR2, rDiff)
  } else{
    l = c(rR2, rRMSE, rDiff)
  }
}


###### Going out ##################################
knime.out <- knime.in[l,]