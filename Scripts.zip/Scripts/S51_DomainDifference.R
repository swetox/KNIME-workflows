########### Unique reliability #############
knime.out <- knime.in
knime.out$"Difference" <- (knime.in$"Domain Threshold"-knime.in$"Domain Value")
knime.out$"AverageDiff" <- mean(knime.in$"Domain Threshold"-knime.in$"Domain Value")
