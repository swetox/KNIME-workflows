library(MESS)

########## Subsets #################
dblood <- subset(knime.in, Compartment == "Cmixven")
dair <- subset(knime.in, Compartment == "Cexh")

########## Calculating endpoints #################
Cmax_Blood = max(dblood$Concentration)
C5h_Blood	= dblood$Concentration[dblood$time == 5*60]
AUC_Blood = auc(dblood$time,dblood$Concentration, type='linear')

Cmax_Air 	= max(dair$Concentration)
C5h_Air	= dair$Concentration[dair$time == 5*60]
AUC_Air	= auc(dair$time,dair$Concentration, type='linear')

########## Going out ##############################
knime.out <- data.frame(
  Cmax_Blood, 
  C5h_Blood, 
  AUC_Blood,
  Cmax_Air,
  C5h_Air, 
  AUC_Air
)
