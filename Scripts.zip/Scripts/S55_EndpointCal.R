library(MESS)
########## Subsets #################
dblood <- subset(knime.in, Compartment == "Cmixven")
dair <- subset(knime.in, Compartment == "Cexh")

lm_blood <- lm(log(Concentration) ~ time, subset(dblood, time>130 & time<400))
lm_air <- lm(log(Concentration) ~ time, subset(dair, time>130 & time<400))

########## Calculating endpoints #################
Cmax_Blood = max(dblood$Concentration)
thalf_Blood	= log(2)/-summary(lm_blood)$coefficients[2]
AUC_Blood = auc(dblood$time,dblood$Concentration, type='linear')

Cmax_Air 	= max(dair$Concentration)
thalf_Air	= log(2)/-summary(lm_air)$coefficients[2]
AUC_Air	= auc(dair$time,dair$Concentration, type='linear')

########## Going out ##############################
knime.out <- data.frame(
  Cmax_Blood, 
  thalf_Blood, 
  AUC_Blood,
  Cmax_Air,
  thalf_Air, 
  AUC_Air
)
