############## Adding info to result of  PBTK ##############
knime.out <- knime.in

knime.out$"Compound" 	= knime.flow.in[["Compound"]]
knime.out$"Exposure" 	= knime.flow.in[["Exposure level"]]
knime.out$"Gender"		= knime.flow.in[["Gender"]]