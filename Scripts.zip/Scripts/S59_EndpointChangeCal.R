################## Change in Endpoint ###########
knime.out <- data.frame(
  "Compound"		= knime.in$"Compound",
  "Exposure"		= knime.in$"Exposure",
  "Gender"			= knime.in$"Gender",
  "PC"				= knime.in$"PC",
  "PCFold"			= knime.in$"PCfold",
  "Cmax_Blood_Fold" 	= knime.in$"Cmax_Blood"/knime.flow.in[["Cmax_Blood"]],
  "thalf_Blood_Fold" 	= knime.in$"thalf_Blood"/knime.flow.in[["thalf_Blood"]],
  "AUC_Blood_Fold" 	= knime.in$"AUC_Blood"/knime.flow.in[["AUC_Blood"]],
  "Cmax_Air_Fold"	= knime.in$"Cmax_Air"/knime.flow.in[["Cmax_Air"]],
  "thalf_Air_Fold"	= knime.in$"thalf_Air"/knime.flow.in[["thalf_Air"]],
  "AUC_Air_Fold"		= knime.in$"AUC_Air"/knime.flow.in[["AUC_Air"]]
)