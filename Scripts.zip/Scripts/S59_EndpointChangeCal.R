################## Change in Endpoint ###########
knime.out <- data.frame(
  "Compound"		= knime.in$"Compound",
  "Exposure"		= knime.in$"Exposure",
  "Gender"			= knime.in$"Gender",
  "PC"				= knime.in$"PC",
  "PCFold"			= knime.in$"PCfold",
  "Cmax_Blood_Fold" 	= knime.in$"Cmax_Blood"/knime.flow.in[["Cmax_Blood"]],
  "C5h_Blood_Fold" 	= knime.in$"C5h_Blood"/knime.flow.in[["C5h_Blood"]],
  "AUC_Blood_Fold" 	= knime.in$"AUC_Blood"/knime.flow.in[["AUC_Blood"]],
  "Cmax_Air_Fold"	= knime.in$"Cmax_Air"/knime.flow.in[["Cmax_Air"]],
  "C5h_Air_Fold"		= knime.in$"C5h_Air"/knime.flow.in[["C5h_Air"]],
  "AUC_Air_Fold"		= knime.in$"AUC_Air"/knime.flow.in[["AUC_Air"]]
)