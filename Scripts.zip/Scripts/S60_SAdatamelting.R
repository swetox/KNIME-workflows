library(reshape2)
################################

knime.out <- melt(knime.in,
                  id.vars 		= c("Compound", "Exposure", "Gender", "PC", "PCFold"), 
                  measure.vars 	= c("Cmax_Blood_Fold", "thalf_Blood_Fold", "AUC_Blood_Fold","Cmax_Air_Fold", "thalf_Air_Fold", "AUC_Air_Fold"),
                  value.name 	= "Fold",
                  variable.name	= "Endpoint")
