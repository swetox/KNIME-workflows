scenario = paste(knime.flow.in[["Compound"]], ", ", knime.flow.in[["Exposure"]], "ppm, ", knime.flow.in[["Gender"]], sep = "")

################### Calculating slop ###################

Cmax_Blood_Slope = coef(lm(Cmax_Blood_Fold ~ PCFold, knime.in))[[2]]
thalf_Blood_Slope = coef(lm(thalf_Blood_Fold  ~ PCFold, knime.in))[[2]]
AUC_Blood_Slope = coef(lm(AUC_Blood_Fold  ~ PCFold, knime.in))[[2]]
Cmax_Air_Slope	= coef(lm(Cmax_Air_Fold ~ PCFold, knime.in))[[2]]
thalf_Air_Slope = coef(lm(thalf_Air_Fold ~ PCFold, knime.in))[[2]]
AUC_Air_Slope = coef(lm(AUC_Air_Fold ~ PCFold, knime.in))[[2]]


######### Going out ###################################
knime.out <- data.frame(
  "Scenario" = scenario,
  "PC" = knime.flow.in[["PC"]],	
  Cmax_Blood_Slope,
  thalf_Blood_Slope,
  AUC_Blood_Slope,
  Cmax_Air_Slope,
  thalf_Air_Slope,
  AUC_Air_Slope
)