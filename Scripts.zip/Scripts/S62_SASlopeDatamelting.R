library(reshape2)
################################

knime.out <- melt(knime.in,
                  id.vars 		= c("Scenario", "PC"), 
                  measure.vars 	= c("Cmax_Blood_Slope", "thalf_Blood_Slope", "AUC_Blood_Slope","Cmax_Air_Slope", "thalf_Air_Slope", "AUC_Air_Slope"),
                  value.name 	= "Slope",
                  variable.name	= "Endpoint")
