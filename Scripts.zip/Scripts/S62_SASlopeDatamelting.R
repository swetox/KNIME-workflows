library(reshape2)
################################

knime.out <- melt(knime.in,
                  id.vars 		= c("Scenario", "PC"), 
                  measure.vars 	= c("Cmax_Blood_Slope", "C5h_Blood_Slope", "AUC_Blood_Slope","Cmax_Air_Slope", "C5h_Air_Slope", "AUC_Air_Slope"),
                  value.name 	= "Slope",
                  variable.name	= "Endpoint")
