########## Scenarios ############

list <- unique(knime.in$"Scenario")

######## Rows to include ########
rows <- c()

for(i in 1:length(list)){
  s <- list[i]
  rows[i] <- match(s, knime.in$"Scenario")
}

####### Going out ###############
first <- match("Compound", colnames(knime.in))

knime.out <- knime.in[rows,first:ncol(knime.in)]