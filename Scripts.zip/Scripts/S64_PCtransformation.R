############# Log or untransformed ##########
nc = match(knime.flow.in[["PCgeneral"]], colnames(knime.in))

knime.out <- knime.in

if(grepl("Log", knime.flow.in[["Transformation"]])){
  knime.out[,nc]		= 10^knime.out[,nc]
}
  