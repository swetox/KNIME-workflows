library(dplyr)

########################
func.range <- function(df){
  min = min(df$Concentration)
  max = max(df$Concentration)
  df.out <- data.frame("Minimum" = min, "Maximum" = max)
  return(df.out)
}

d<- knime.in %>% 
  group_by(Compartment, time) %>%
  do(func.range(.))

knime.out <- data.frame(d)