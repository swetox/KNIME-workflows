knime.out <- knime.in
knime.out$"Source" <- knime.flow.in[["Source"]]