##########################################

d_air_ex <- subset(knime.in, Compartment == "Exhaled air")
d_blood_ex <- subset(knime.in, Compartment == "Blood")
d_air_pbtk <- subset(knime.in, Compartment == "Cexh")
d_blood_pbtk <- subset(knime.in, Compartment == "Cmixven")

############################################

time_air_ex <- as.character(unique(d_air_ex$time))
time_blood_ex <- as.character(unique(d_blood_ex$time))

time_air_pbtk <- as.character(unique(d_air_pbtk$time))
time_blood_pbtk <- as.character(unique(d_blood_pbtk$time))

############## Filter ########################
nair <- which(time_air_pbtk %in% time_air_ex)
nblood <- which(time_blood_pbtk %in% time_blood_ex)

############# Going out ##########################
knime.out <- rbind(d_air_ex, d_blood_ex, d_air_pbtk[nair,], d_blood_pbtk[nblood,])