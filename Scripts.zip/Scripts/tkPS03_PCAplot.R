###############################
########## Libraries ###########
library(ggplot2)

mytheme = base_size = 14
mytheme <- theme(
  text =					element_text(family = "Arial"),			
  title =					element_text(family = "Arial"),			
  
  axis.line =         	element_line(colour = "black"),
  axis.text.x =       	element_text(size = base_size * 0.8 , face = "bold", lineheight = 0.9, colour = "black", vjust = 1),
  axis.text.y =       	element_text(size = base_size * 0.8, face = "bold", lineheight = 0.9, colour = "black", hjust = 1),
  axis.ticks =        	element_line(colour = "black"),
  axis.title.x =      	element_text(size = base_size, face = "bold", vjust = 0.5),
  axis.title.y =      	element_text(size = base_size, face = "bold", angle = 90, vjust = 0.5),
  axis.ticks.length = 	unit(0.15, "cm"),
  axis.ticks.margin = 	unit(0.1, "cm"),
  
  legend.background = element_rect(colour=NA), 
  legend.key =        element_rect(fill = NA, colour = "black", size = 0.25),
  legend.key.size =   unit(1.2, "lines"),
  legend.text =       element_text(size = base_size * 0.8),
  legend.title =      element_text(size = base_size * 0.8, face = "bold", hjust = 0),
  legend.position =   "bottom",
  
  panel.background =  element_rect(fill = NA, colour = NA, size = 0.25), 
  panel.border =      element_blank(),
  panel.grid.major =  element_line(colour = NA, size = 0.05),
  panel.grid.minor =  element_line(colour = NA, size = 0.05),
  panel.margin =      unit(0.25, "lines"),
  
  strip.background =  element_rect(fill = NA, colour = NA), 
  strip.text.x =      element_text(colour = "black", face = "bold", size = base_size),
  strip.text.y =      element_text(colour = "black", face = "bold", size = base_size, angle = -90),
  
  plot.background =   element_rect(colour = NA, fill = "white"),
  plot.title =        element_text(size = base_size * 1.2, face = "bold"),
  plot.margin =       unit(c(1, 1, 0.5, 0.5), "lines")
)
####################################################
########## Boundaries and colours and sizes ########
dimensions = paste("d = ", unique(knime.in$"Dimensions")[1], sep ="")

max = ceiling(max(knime.in$"PCA dimension 0", knime.in$"PCA dimension 1"))
min = floor(min(knime.in$"PCA dimension 0", knime.in$"PCA dimension 1"))
lims = c(min, max)
n = length(unique(knime.in$"Compound"))-1

size = 4
pshape = c(21, rep(22,n))
pcol = c("grey20", scales::hue_pal()(n))
pfill = c(NA, scales::hue_pal()(n))
lcol = "grey"
lwd = 0.8
##############################
colnames(knime.in) <- c("PCA0", "PCA1", "Compound", "Dimensions", "PC")

ggplot(subset(knime.in, PC != "PCbrain" & PC != "PCkidney"), aes(x = PCA0, y = PCA1, color = Compound, shape = Compound, fill = Compound )) + mytheme +
  geom_point(size = size) +
  scale_shape_manual(values = pshape) +
  scale_fill_manual(values = pfill) +
  scale_colour_manual(values = pcol)+
  theme(legend.title = element_blank()) + 
  facet_wrap(~PC, ncol = 3, scales =  "free")