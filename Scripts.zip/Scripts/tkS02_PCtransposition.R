############################

knime.out <- knime.in[,c(1,3)]
colnames(knime.out)[2] <- "Prediction"
knime.out$"PC" = colnames(knime.in)[3]