####### Parameters needed for PBTK #################

knime.out <- data.frame(
  "solvingmethod" 		= "lsoda",
  "Ventilation work" 		= knime.flow.in[["Ventilation work"]],
  "Ventilation rest"		= knime.flow.in[["Ventilation rest"]],
  "Molar volume"			= unique(knime.in$"Molecular weight"),
  "Exposure level"		= knime.flow.in[["Exposure level"]],
  "Body height" 			= knime.flow.in[["Body height"]],
  "Body weight"			= knime.flow.in[["Body weight"]],
  "CLi"				= knime.flow.in[["Clearance"]],
  "PCblood"				= knime.in$"PCblood",
  "PCfat"				= knime.in$"PCfat",
  "PClung"				= knime.in$"PClung",
  "PCmuscle"			= knime.in$"PCmuscle",
  "PCliver"				= knime.in$"PCliver",
  "PCvessel"			= knime.in$"PCvessel",
  "WDperWeek"			= knime.flow.in[["WDperWeek"]],	# Work days per week
  "WHperDay"			= knime.flow.in[["WHperDay"]],	# work hours per day
  "SimLength"			= knime.flow.in[["SimulationLength"]] # length of simulation in days
)

colnames(knime.out) <- c("solvingmethod", "Ventilation work", "Ventilation rest", "Molar volume", "Exposure level", "Body height", "Body weight", "CLi", "PCblood", "PCfat", "PClung", "PCmuscle", "PCliver", "PCvessel","WDperWeek","WHperDay", "SimLength") 