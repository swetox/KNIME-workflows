#################################################
library(dplyr)
library(MESS)

func <- function(t,c){
  cmax = round(max(c),1)
  AUC = round(auc(t,c, type='linear'))
  df.out <- data.frame(cmax,AUC)
  return(df.out)
}

d<- knime.in %>%
  group_by(Compartment) %>%
  do(func(as.vector(.$time),as.vector(.$Concentration)))


############### Going out ################################
knime.out <- data.frame(
  "Comp" = paste(as.character(d$Compartment), collapse =","),
  "Cmax" = paste(as.character(d$cmax), collapse = ","),
  "AUC" = paste(as.character(d$AUC), collapse =",")
)