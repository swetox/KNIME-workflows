############################

knime.out <- knime.in
colnames(knime.out)[1] <- "Prediction"
knime.out$"PC" = colnames(knime.in)[1]