######### Statistics plot ######
########## Libraries ###########
library(ggplot2)

mytheme = base_size = 14
mytheme <- theme(
  text =					element_text(family = "Arial"),			
  title =					element_text(family = "Arial"),			
  
  axis.line =         	element_line(colour = "black"),
  axis.text.x =       	element_text(size = base_size * 0.8 , face = "bold", lineheight = 0.9, colour = "black", vjust = 1),
  axis.text.y =       	element_text(size = base_size * 0.8, face = "bold", lineheight = 0.9, colour = "black", hjust = 1),
  axis.ticks =        	element_line(colour = "black"),
  axis.title.x =      	element_text(size = base_size, face = "bold", vjust = 0.5),
  axis.title.y =      	element_text(size = base_size, face = "bold", angle = 90, vjust = 0.5),
  axis.ticks.length = 	unit(0.15, "cm"),
  axis.ticks.margin = 	unit(0.1, "cm"),
  
  legend.background = element_rect(colour=NA), 
  legend.key =        element_rect(fill = NA, colour = "black", size = 0.25),
  legend.key.size =   unit(1.2, "lines"),
  legend.text =       element_text(size = base_size * 0.8),
  legend.title =      element_text(size = base_size * 0.8, face = "bold", hjust = 0),
  legend.position =   "bottom",
  
  panel.background =  element_rect(fill = NA, colour = NA, size = 0.25), 
  panel.border =      element_blank(),
  panel.grid.major =  element_line(colour = NA, size = 0.05),
  panel.grid.minor =  element_line(colour = NA, size = 0.05),
  panel.margin =      unit(0.25, "lines"),
  
  strip.background =  element_rect(fill = NA, colour = NA), 
  strip.text.x =      element_text(colour = "black", face = "bold", size = base_size),
  strip.text.y =      element_text(colour = "black", face = "bold", size = base_size, angle = -90),
  
  plot.background =   element_rect(colour = NA, fill = "white"),
  plot.title =        element_text(size = base_size * 1.2, face = "bold"),
  plot.margin =       unit(c(1, 1, 0.5, 0.5), "lines"),
  aspect.ratio = 1
)

########## Boundaries and colours and sizes ########

max = ceiling(max(knime.in$"Observed", knime.in$"Predicted"))
min = floor(min(knime.in$"Observed", knime.in$"Predicted"))
lims = c(min, max)
b <- ifelse(grepl("LogPC", knime.flow.in[["PC"]])== TRUE, -1, 0.1*max)

size = 3
pshape = c(21, 22, 23, 24, 25)
pcol = c("grey20", "black", "black", "black", "black")
pfill = c(NA, "black", "black", "black", "black") 
lcol = "grey"
lwd = 0.8

########### Labels ############
if(grepl("Log", knime.flow.in[["PC"]])){
  xlabel = "Log(observed)"
  ylabel = "Log(predicted)"
} else {
  xlabel = "Oserved"
  ylabel = "Predicted"
}

##############################
ggplot(knime.in, aes(x = Observed, y = Predicted, group = Origin, colour = Origin, shape = Origin, fill = Origin)) + mytheme + 
  geom_abline(slope = 1, intercept = 0, colour = lcol, lwd = lwd) +
  geom_abline(slope = 1, intercept = (-b), colour = lcol, lty = 2, lwd = lwd) +
  geom_abline(slope = 1, intercept = b, colour = lcol, lty = 2, lwd = lwd) +
  geom_point(size = size) +
  scale_x_continuous(limits = lims, expand = c(0,0))+
  scale_y_continuous(limits = lims, expand = c(0,0))+
  scale_shape_manual(values = pshape) +
  scale_fill_manual(values = pfill) +
  scale_colour_manual(values = pcol) +
  labs(x = xlabel, y = ylabel) +
  theme(legend.title = element_blank(), legend.position = c(0.85, 0.2))


######### Saving plot #############
pc = knime.flow.in[["PC"]]
combo = unique(knime.in$"Combo")[1]
output = unique(knime.in$"Output")[1]
generation = knime.flow.in[["Generation"]]
path = knime.flow.in[["plotfolder"]]
name = paste(generation, output, "_", pc, "_", combo, ".tiff", sep = "") 

ggsave(filename = name, path = path, device = "tiff", dpi = 300, height = 4.5, unit = "in")


