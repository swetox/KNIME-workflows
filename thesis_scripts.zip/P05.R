########## Libraries #########
library(ggplot2)

mytheme = base_size = 14
mytheme <- theme(
  text =					element_text(family = "Arial"),			
  title =					element_text(family = "Arial"),			
  
  axis.line =         	element_line(colour = "black"),
  axis.text.x =       	element_text(size = base_size * 0.8 , face = "bold", lineheight = 0.9, colour = "black", vjust = 1),
  axis.text.y =       	element_text(size = base_size * 0.8, face = "bold", lineheight = 0.9, colour = "black", hjust = 1),
  axis.ticks =        	element_line(colour = "black"),
  axis.title.x =      	element_text(size = base_size, face = "bold", vjust = 0.5),
  axis.title.y =      	element_text(size = base_size, face = "bold", angle = 90, vjust = 0.5),
  axis.ticks.length = 	unit(0.15, "cm"),
  axis.ticks.margin = 	unit(0.1, "cm"),
  
  legend.background = element_rect(colour=NA), 
  legend.key =        element_rect(fill = NA, colour = "black", size = 0.25),
  legend.key.size =   unit(1.2, "lines"),
  legend.text =       element_text(size = base_size * 0.8),
  legend.title =      element_text(size = base_size * 0.8, face = "bold", hjust = 0),
  legend.position =   "bottom",
  
  panel.background =  element_rect(fill = NA, colour = NA, size = 0.25), 
  panel.border =      element_blank(),
  panel.grid.major =  element_line(colour = NA, size = 0.05),
  panel.grid.minor =  element_line(colour = NA, size = 0.05),
  panel.margin =      unit(0.25, "lines"),
  
  strip.background =  element_rect(fill = NA, colour = NA), 
  strip.text.x =      element_text(colour = "black", face = "bold", size = base_size),
  strip.text.y =      element_text(colour = "black", face = "bold", size = base_size, angle = -90),
  
  plot.background =   element_rect(colour = NA, fill = "white"),
  plot.title =        element_text(size = base_size * 1.2, face = "bold"),
  plot.margin =       unit(c(1, 1, 0.5, 0.5), "lines")
)
######### Levels ################

levels(knime.in$"Parameter")  <- c("R[OOB]^2", "RMSE[OOB]~(logscaled)")

######## Plotting ################


pcolor <- ggplot(knime.in, aes(x = No, y = Value, colour = PClabel, linetype = Data)) + mytheme + 
  geom_line(lwd = 0.6) + 
  #scale_color_grey() + 
  guides(linetype = guide_legend(nrow = 2)) +
  labs(x = "Number of descriptors", y = "Percental change") + 
  scale_y_continuous(expand= c(0,0)) +
  coord_cartesian(ylim = c(-5,5)) + 
  facet_grid(Parameter~., 
             switch = "both", 
             scales = "free", 
             labeller = labeller(Parameter = label_parsed)) + 
  theme(#axis.title.x = element_blank(),
    #axis.title.y = element_blank(),
    legend.title = element_blank(), 
    strip.placement.y = "outside",
    strip.placement.x = "outside",
    legend.position = "top",
    legend.text = element_text(size = 9),
    legend.key.size = unit(9, "pt"),
    panel.spacing.y = unit(8, "pt")
  )


pgrey <- ggplot(knime.in, aes(x = No, y = Value, colour = PClabel, linetype = Data)) + mytheme + 
  geom_line(lwd = 0.6) + 
  scale_color_grey() + 
  guides(linetype = guide_legend(nrow = 2)) +
  labs(x = "Number of descriptors", y = "Percental change") + 
  scale_y_continuous(expand= c(0,0)) +
  coord_cartesian(ylim = c(-5,5)) + 
  facet_grid(Parameter ~., 
             switch = "y", 
             scales = "free", 
             labeller = labeller(Parameter = label_parsed)) + 
  theme(#axis.title.x = element_blank(),
    #axis.title.y = element_blank(),
    legend.title = element_blank(), 
    strip.placement.y = "outside",
    strip.placement.x = "outside",
    legend.position = "top",
    legend.text = element_text(size = 9),
    legend.key.size = unit(9, "pt"),
    panel.spacing.y = unit(8, "pt")
  )
pgrey

######## Saving plot ##########
type = gsub("[0-9a-z]*", "", knime.flow.in[["Generation"]])
folder = knime.flow.in[["evaluationplotfolder"]]
nameColor = paste(knime.flow.in[["Generation"]], "plot_color.tiff", sep = "") 
nameGrey = paste(knime.flow.in[["Generation"]], "plot_grey.tiff", sep = "") 

ggsave(plot = pcolor, filename = nameColor, path = folder, device = "tiff", dpi = 300, width = 6.5, height = 4.5, unit = "in")
ggsave(plot = pgrey, filename = nameGrey, path = folder, device = "tiff", dpi = 300, width = 6.5, height = 4.5, unit = "in")
