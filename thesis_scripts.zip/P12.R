library(ggplot2)


mytheme = base_size = 14
mytheme <- theme(
  text =					element_text(family = "Arial"),			
  title =					element_text(family = "Arial"),			
  
  axis.line =         	element_line(colour = "black"),
  axis.text.x =       	element_text(size = base_size * 0.8 , face = "bold", lineheight = 0.9, colour = "black", vjust = 1),
  axis.text.y =       	element_text(size = base_size * 0.8, face = "bold", lineheight = 0.9, colour = "black", hjust = 1),
  axis.ticks =        	element_line(colour = "black"),
  axis.title.x =      	element_text(size = base_size*0.8, face = "bold", vjust = 0.5),
  axis.title.y =      	element_text(size = base_size*0.8, face = "bold", angle = 90, vjust = 0.5),
  axis.ticks.length = 	unit(0.15, "cm"),
  axis.ticks.margin = 	unit(0.1, "cm"),
  
  legend.background = element_rect(colour=NA), 
  legend.key =        element_rect(fill = NA, colour = "black", size = 0.25),
  legend.key.size =   unit(1.2, "lines"),
  legend.text =       element_text(size = base_size * 0.6),
  legend.title =      element_text(size = base_size * 0.6, face = "bold", hjust = 0),
  legend.position =   "bottom",
  
  panel.background =  element_rect(fill = NA, colour = "grey80", size = 0.25), 
  panel.border =      element_blank(),
  panel.grid.major =  element_line(colour = NA, size = 0.05),
  panel.grid.minor =  element_line(colour = NA, size = 0.05),
  panel.margin =      unit(0.25, "lines"),
  
  strip.background =  element_rect(fill = "grey85", colour = NA), 
  strip.text.x =      element_text(colour = "black", face = "bold", size = base_size*0.8),
  strip.text.y =      element_text(colour = "black", face = "bold", size = base_size*0.8, angle = -90),
  
  plot.background =   element_rect(colour = NA, fill = "white"),
  plot.title =        element_text(size = base_size * 1.2, face = "bold"),
  plot.margin =       unit(c(1, 1, 0.5, 0.5), "lines"),
  aspect.ratio = 1
)
capitalize <- function(string) {
  substr(string, 1, 1) <- toupper(substr(string, 1, 1))
  string
}

df_plot = knime.in
df_plot = transform(df_plot, "endpoint" = gsub("210<t<360", "", df_plot$endpoint)) #bold(210\u003c~t\u003c~360)
df_plot = transform(df_plot, "endpoint" = gsub("halftime\\[\\]", "half~time", df_plot$endpoint))
df_plot = transform(df_plot, "parameter" = paste("bold(", gsub("log\\(","",  gsub("qwork", "Q[work]", gsub("qrest", "Q[rest]", gsub("bw", "BW", gsub("bh", "BH", df_plot$parameter))))), sep =""))
df_plot = transform(df_plot, "corr" = ifelse(df_plot$pvalue > 0.05, 0, df_plot$corr))


ggplot(df_plot, aes(x = parameter, y = corr, fill = endpoint)) + mytheme +
  geom_col(position = position_dodge()) +
  scale_fill_grey(labels = unlist(lapply(unique(df_plot$endpoint), function(x) {parse(text=x)}))) + 
  facet_grid(tissue~., labeller = labeller(tissue = capitalize), switch = "y") +
  coord_flip() +
  labs(y  = "Correlation") +
  theme(axis.title.y = element_blank(),
        legend.title = element_blank(),
        legend.position = "right") +
  scale_x_discrete(label = parse(text=c(rev(df_plot$parameter))), limits = rev(unique(df_plot$parameter))) +
  geom_hline(yintercept = 0.0, colour = "grey50")

######## Saving plot ##########
folder = knime.flow.in[["plotfolder"]]
setup = paste(knime.flow.in[["Compound"]], knime.flow.in[["Gender"]],knime.flow.in[["Exposure level"]], sep="")
source = ifelse(grepl("Ernst", knime.flow.in[["Source"]]), "ernstgaard", knime.flow.in[["Source"]])
name = paste("SAvariability_", setup, "_correlations_", source, ".tiff", sep ="")
ggsave(filename = name, path = folder, device = "tiff", dpi = 300, width = 6.5, height = 4.5, unit = "in")