######## Generating correct folder names #############
###### For folders located in KNIME folder ########

#### All workflows should be located 
#### in "workspace" in the folder KNIME

####### Computer specific settings #########
####### Fixing correct babel #################
macbabel 		= "/usr/local/bin/babel"
windowsbabel 	= "/C:/Program Files/KNIME/plugins/org.knime.ext.chem.openbabel.bin.win32.x86_2.3.1.v201701191301/win32/x86/babel.exe"

computer = Sys.info()[["sysname"]]

if(computer == "Darwin"){
  babelstring = macbabel
  sepo = "/"
} else {
  babelstring = windowsbabel
  sepo = "\\"
}

#######################################

# Base folder:
basefolder = gsub("workspace","", knime.flow.in[["knime.workspace"]])

###### headfolders Data and results #####
datafolder 	= paste(basefolder, "data", sepo, sep = "")
resultsfolder 	= paste(basefolder, "results", sepo, sep ="")


knime.out <- data.frame(
  ##### Specific folders ###################
  resultsfolder 	= resultsfolder, 
  editedfolder		= paste(datafolder, "edited", sepo, sep =""),
  hfcfolder		= paste(datafolder, "HFCs", sep =""),
  outputdatafolder 	= paste(resultsfolder, "outputdata", sepo, sep =""),
  infofolder 		= paste(resultsfolder, "info", sepo, sep =""),
  plotfolder		= paste(resultsfolder, "adpplots", sep =""),
  
  ##### Specific files ####################
  datasubsetname			= "Data_subsetlist",
  hfcname					= "HFC_PCs_2014",
  optimizationdescriptorsname	= "OptimizationDescriptors",
  predictionname			= "PredictionADP",
  modelstatsname			= "ModelStats",
  modeloutputdataname 		= "ModelOutputdata",
  
  ######## Others ########################
  datasheet = "All subsets",
  hfcsheet = "Reported values",
  sepo = sepo,
  "babelstring" = babelstring
  
  
)
