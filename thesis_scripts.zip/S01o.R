######## Generating correct folder names #############
###### For folders located in KNIME folder ########

#### All workflows should be located 
#### in "workspac" in the folder KNIME

####### Computer specific settings #########
####### Fixing correct babel #################
macbabel 		= "/usr/local/bin/babel"
windowsbabel 	= "/C:/Program Files/KNIME/plugins/org.knime.ext.chem.openbabel.bin.win32.x86_2.3.1.v201701191301/win32/x86/babel.exe"

computer = Sys.info()[["sysname"]]

if(computer == "Darwin"){
  babelstring = macbabel
  sepo = "/"
} else {
  babelstring = windowsbabel
  sepo = "\\"
}

#######################################

# Base folder:
basefolder = gsub("workspace","", knime.flow.in[["knime.workspace"]])

###### headfolders Data and results #####
datafolder 	= paste(basefolder, "data", sepo, sep = "")
resultsfolder 	= paste(basefolder, "results", sepo, sep ="")


knime.out <- data.frame(
  ##### Specific folders ###################
  experimentalfolder		= paste(datafolder, "experimental", sep =""),
  infofolder 		= paste(resultsfolder, "info", sepo, sep =""),
  hfcfolder			= paste(datafolder, "HFCs", sep =""),
  evaluationplotfolder= paste(resultsfolder, "evaluationplots", sep =""),
  plotfolder		= paste(resultsfolder, "sensitivityplots", sep =""),
  outputfolder 	= paste(resultsfolder, "outputdata", sep =""),
  physiofolder		= paste(datafolder, "physiologically", sep =""),
  
  ##### Specific files ####################
  hfcaveragename			= "HFCaveragedata",
  decriptivestatname		= "DescriptiveStats",
  modelselectionname		= "ModelSelection",
  sensitivityname			= "SensitivityAnalysis", 
  sensitivityoutname		= "SensitivityTKendpoints",
  physioname 				= "physiologicallyparameters",
  predictionname 			= "PredictionADP",
  reportedpcsname			= "HFC_PCs_2014",
  
  ######## Others ########################
  hfcsheet = "Reported values",
  statssheet = "All data",
  selectionsheet = "SelectionGeneral",
  exposuresetupsheet = "Setup",
  uncertaintysheet = "uncertainty",
  variabilitysheet = "variability",
  extremessheet = "extremes",
  physiosheet	= "physioinfo",
  distributionsheet = "distributions",
  predictionsheet = "All"
  
)
knime.flow.in[["knime.workspace"]]