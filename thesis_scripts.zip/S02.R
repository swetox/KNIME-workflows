### Adding PCvessel
knime.in$"PCvessel_P2" <- rowMeans(knime.in[,c(3,7)])
knime.out <- knime.in