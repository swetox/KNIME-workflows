library(fitdistrplus)

####### Descriptive statistics #######

n		<- length(knime.in$"Value")
shapiro 	<- shapiro.test(knime.in$"Value")$p.value
mean 	<- mean(knime.in$"Value")
min 		<- min(knime.in$"Value")
max		<- max(knime.in$"Value")
sd 		<- sd(knime.in$"Value")

min_compound <- knime.in$"Compound"[match(min(knime.in$"Value"),knime.in$"Value")]
max_comopund <- knime.in$"Compound"[match(max(knime.in$"Value"),knime.in$"Value")]

###### Going out ###########
knime.out 		<- data.frame("PC" = knime.flow.in[["PC"]])
knime.out$"n"		<- n
knime.out$"Shapiro p-value" <- shapiro
knime.out$"Mean" 	<- mean
knime.out$"Min" 	<- min
knime.out$"Max" 	<- max
knime.out$"SD"		<- sd

######## Distribution analysis ##############
x = knime.in$"Value"

filepath_desc = paste(knime.flow.in[["densityplotfolder"]], "//", knime.flow.in[["PC"]], "fitdistplot_summary.tiff", sep ="")
tiff(filepath_desc, width = 6.5, height = 4.5, unit = "in", res = 300)
descdist(x, discrete = FALSE)
dev.off()

fit.norm <- fitdist(x, "norm",  method="mge")
fit.uni <- fitdist(x, "unif", method="mge", gof="KS")
fits = list(fit.norm, fit.uni)
legend = c("normal", "uniform")

filepath_desc = paste(knime.flow.in[["densityplotfolder"]], "//", knime.flow.in[["PC"]], "fitdistplot_dists.tiff", sep ="")
tiff(filepath_desc, width = 6.5, height = 4.5, unit = "in", res = 300)
par(mfrow = c(2,2))
cdfcomp(fits, legendtext=legend)
denscomp(fits, legendtext=legend)
qqcomp(fits, legendtext=legend)
ppcomp(fits, legendtext=legend)
dev.off()