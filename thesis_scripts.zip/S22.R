######## Descriptors as columns ########
col = knime.in$"Descriptors"

knime.out <- data.frame(matrix(NA, ncol = nrow(knime.in), nrow = 1))
colnames(knime.out) <- col
knime.out <- cbind("Compound" = "c", "Value" = 1.2, knime.out)