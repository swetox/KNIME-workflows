######## Generating model name ######
knime.out <- knime.in

##################
generation 	= knime.flow.in[["Generation"]]
pc 			= knime.flow.in[["PC"]]
name = paste(generation, "_", pc, "_MD", sep = "")

knime.out$"LRmodelname" <- name