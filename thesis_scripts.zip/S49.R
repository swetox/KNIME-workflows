############### Adding info on PC ################
knime.out <- knime.in
knime.out$"PC" <- knime.flow.in[["PCgeneral"]]