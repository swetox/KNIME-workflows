########## Renaming #############################
colnames(knime.in) <- c("Compound", "Domain Value", "Domain Threshold", "Reliability", "PC prediction")

############## Adding info #######################
if(grepl("Log", knime.flow.in[["PC"]])){
  knime.in$"PC prediction" 	= 10^knime.in$"PC prediction"
  knime.in$"Transformation" 	= "Log"
  knime.in$"RMSEtrans"		= knime.flow.in[["RMSE"]]
} else {
  knime.in$"Transformation" 	= "Non"
  knime.in$"RMSEtrans"		= log10(knime.flow.in[["RMSE"]])
}

filename_split = unlist(strsplit(knime.flow.in[["Modelfile"]], "[\\]"))
filename = filename_split[length(filename_split)]
folder =  filename_split[length(filename_split)-1]

knime.in$Tissue	<- knime.flow.in[["Tissue"]]
knime.in$Generation <- knime.flow.in[["Generation"]]
knime.in$R2		<- knime.flow.in[["R2abs"]]
knime.in$RMSE		<- knime.flow.in[["RMSE"]]
knime.in$Modelfile	<- filename
knime.in$Folder 	<- folder
knime.in$Type		<- knime.flow.in[["Type"]]
knime.in$Combo		<- knime.flow.in[["Combo"]]
knime.in$PC		<- knime.flow.in[["PC"]]
knime.in$Data		<- knime.flow.in[["Data"]]

########### Column selection ####################
rTissue 		= match("Tissue", colnames(knime.in))
rGeneration 	= match("Generation", colnames(knime.in))
rCompound		= match("Compound", colnames(knime.in))
rPCprediction 	= match("PC prediction", colnames(knime.in))
rDomainV 		= match("Domain Value", colnames(knime.in))
rDomainT 		= match("Domain Threshold", colnames(knime.in))
rReliability 	= match("Reliability", colnames(knime.in))
rR2 			= match("R2", colnames(knime.in))
rRMSE 		= match("RMSE", colnames(knime.in))
rRMSEtrans	= match("RMSEtrans", colnames(knime.in))
rModelfile 	= match("Modelfile", colnames(knime.in))
rFolder		= match("Folder", colnames(knime.in))
rType 		= match("Type", colnames(knime.in))
rCombo 		= match("Combo", colnames(knime.in))
rTransformation= match("Transformation", colnames(knime.in))
rData 		= match("Data", colnames(knime.in))
rPC 			= match("PC", colnames(knime.in))

c = c(	rTissue, 
       rGeneration,
       rPC,
       rCompound, 
       rPCprediction, 
       rDomainV,
       rDomainT,
       rReliability, 
       rR2,
       rRMSE, 
       rRMSEtrans,
       rModelfile,
       rFolder, 
       rType, 
       rCombo, 
       rData,
       rTransformation
)

############ Going out #############################
knime.out <- knime.in[,c]