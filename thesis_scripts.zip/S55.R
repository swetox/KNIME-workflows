library(reshape2)
knime.out = melt(knime.in, id.vars = c("Compound", "Source"), measure.vars = colnames(knime.in)[c(4,6, 8:ncol(knime.in))], value.name = "PC value", variable.name = "Tissue")
knime.out$Tissue = gsub("PC", "", knime.out$Tissue)
