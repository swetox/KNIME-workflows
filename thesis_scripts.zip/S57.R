library(ggplot2)


if(knime.flow.in[["Parameter"]] == "bh"| knime.flow.in[["Parameter"]] == "bw"){
  dist = knime.in$Distribution[knime.in$Specification == "mean"]
  unit = knime.in$Unit[knime.in$Specification == "mean"]
  mean = knime.in$Value[knime.in$Specification == "mean"]
  q25 = knime.in$Value[knime.in$Specification == "q25"]
  q75 = knime.in$Value[knime.in$Specification == "q75"]
  
  # Converting quantiles to sd:
  sd_25 = (mean-q25)/0.675
  sd_75 = (mean-q75)/-0.675
  sd = mean(c(sd_25, sd_75))
  q10 = knime.in$Value[knime.in$Specification == "q10"]
  q90 = knime.in$Value[knime.in$Specification == "q90"]
  extension = ifelse(knime.flow.in[["Parameter"]] == "bh", 20,10)
  min = q10-extension
  max = q90+extension
  
  knime.out <- data.frame("Parameter" = knime.flow.in[["Parameter"]],
                          "Gender" = knime.flow.in[["Gender"]],
                          "Specification" = c("mean", "sd", "min", "max"),
                          "Value" = c(mean, sd, min, max),
                          "Distribution" = dist,
                          "Unit" = unit)
  
} else if(knime.flow.in[["Parameter"]] == "q"){
  dist = knime.in$Distribution[knime.in$Specification == "rest_mean"]
  unit = knime.in$Unit[knime.in$Specification == "rest_mean"]
  qrest_mean = knime.in$Value[knime.in$Specification == "rest_mean"]
  qrest_sd = knime.in$Value[knime.in$Specification == "rest_sd"]
  qrest_min = knime.in$Value[knime.in$Specification == "rest_min"]
  qrest_max = knime.in$Value[knime.in$Specification == "rest_max"]
  qwork_mean = knime.in$Value[knime.in$Specification == "work_mean"]
  qwork_sd = knime.in$Value[knime.in$Specification == "work_sd"]
  qrest_bw_cor = knime.in$Value[knime.in$Specification == "rest_bw_cor"]
  qwork_bw_cor = knime.in$Value[knime.in$Specification == "work_bw_cor"]
  
  
  qratio_median = c() 
  for(i in 1:1000){
    qrest = rnorm(10000, log(qrest_mean), log(qrest_sd))
    qwork = rnorm(10000, log(qwork_mean), log(qwork_sd))
    m = median(qwork)/median(qrest)
    qratio_median[i] = m
  }
  trans = match.fun(gsub("normal", "", dist))
  qrest = rnorm(10000, trans(qrest_mean), trans(qrest_sd))
  qwork = rnorm(10000, trans(qwork_mean), trans(qwork_sd))
  plotname = paste(knime.flow.in[["plotfolder"]], "//Qdistribution_", knime.flow.in[["Gender"]], ".png", sep ="")
  png(plotname)
  par(mfrow = c(1,3))
  hist(qrest, freq = FALSE)
  curve(dnorm(x, mean=trans(qrest_mean), sd=trans(qrest_sd)), add=TRUE, col="red", lwd=2)
  hist(qwork, freq = FALSE)
  curve(dnorm(x, mean=trans(qwork_mean), sd=trans(qwork_sd)), add=TRUE, col="red", lwd=2)
  hist(qratio_median, freq = FALSE)
  curve(dnorm(x, mean=mean(qratio_median), sd=sd(qratio_median)), add=TRUE, col="red", lwd=2)
  dev.off()
  
  knime.out <-  data.frame("Parameter" = c("qrest", "qrest",  "qrest", "qrest", "qrest", "qwork", "qwork", "qwork", "qwork", "qwork"),
                           "Gender" = knime.flow.in[["Gender"]],
                           "Specification" = c("qrest_mean", "qrest_sd","qrest_min", "qrest_max", "bw_cor", "qratio_mean", "qratio_sd","qratio_min", "qratio_max", "bw_cor"),
                           "Value" = c(qrest_mean, qrest_sd, qrest_min, qrest_max, qrest_bw_cor, mean(qratio_median), sd(qratio_median), min(qratio_median), max(qratio_median), qwork_bw_cor), 
                           "Distribution" = dist,
                           "Unit" = unit)
  
}
