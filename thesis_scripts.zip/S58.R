knime.out <- knime.in[,c(3, 1, 4)]
colnames(knime.out) = c("Compound", "Tissue",  "PC value")
knime.out$Source = "QSPR"