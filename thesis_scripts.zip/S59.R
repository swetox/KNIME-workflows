library(tmvtnorm)

# population size
popsize = knime.flow.in[["n"]]

# BH measures
bh_dist = knime.in$"Distribution"[knime.in$"Parameter" == "bh" & knime.in$"Specification" == "mean"]
bh_unit = knime.in$"Unit"[knime.in$"Parameter" == "bh" & knime.in$"Specification" == "mean"]
bh_trans = match.fun(gsub("normal", "", bh_dist))
bh_mean = bh_trans(knime.in$"Value"[knime.in$"Parameter" == "bh" & knime.in$"Specification" == "mean"])
bh_sd = bh_trans(knime.in$"Value"[knime.in$"Parameter" == "bh" & knime.in$"Specification" == "sd"])
bh_min = bh_trans(knime.in$"Value"[knime.in$"Parameter" == "bh" & knime.in$"Specification" == "min"])
bh_max = bh_trans(knime.in$"Value"[knime.in$"Parameter" == "bh" & knime.in$"Specification" == "max"])
bh_bw_cor = 0.0
bh_qrest_cor = 0.0
bh_qwork_cor = 0.0

# BW measures
bw_dist = knime.in$"Distribution"[knime.in$"Parameter" == "bw" & knime.in$"Specification" == "mean"]
bw_unit = knime.in$"Unit"[knime.in$"Parameter" == "bw" & knime.in$"Specification" == "mean"]
bw_trans = match.fun(gsub("normal", "", bw_dist))
bw_mean = bw_trans(knime.in$"Value"[knime.in$"Parameter" == "bw" & knime.in$"Specification" == "mean"])
bw_sd = bw_trans(knime.in$"Value"[knime.in$"Parameter" == "bw" & knime.in$"Specification" == "sd"])
bw_min = bw_trans(knime.in$"Value"[knime.in$"Parameter" == "bw" & knime.in$"Specification" == "min"])
bw_max = bw_trans(knime.in$"Value"[knime.in$"Parameter" == "bw" & knime.in$"Specification" == "max"])
bw_bw_cor = 1.0

# Qrest
qrest_dist = knime.in$"Distribution"[knime.in$"Parameter" == "qrest" & knime.in$"Specification" == "qrest_mean"]
qrest_unit = knime.in$"Unit"[knime.in$"Parameter" == "qrest" & knime.in$"Specification" == "qrest_mean"]
q_trans = match.fun(gsub("normal", "", qrest_dist))
qrest_mean = q_trans(knime.in$"Value"[knime.in$"Parameter" == "qrest" & knime.in$"Specification" == "qrest_mean"])
qrest_sd = q_trans(knime.in$"Value"[knime.in$"Parameter" == "qrest" & knime.in$"Specification" == "qrest_sd"])
qrest_min = q_trans(knime.in$"Value"[knime.in$"Parameter" == "qrest" & knime.in$"Specification" == "qrest_min"])
qrest_max = q_trans(knime.in$"Value"[knime.in$"Parameter" == "qrest" & knime.in$"Specification" == "qrest_max"])
qrest_bw_cor = knime.in$"Value"[knime.in$"Parameter" == "qrest" & knime.in$"Specification" == "bw_cor"]
qrest_qwork_cor = 0.0

# Qrest
qwork_dist = knime.in$"Distribution"[knime.in$"Parameter" == "qwork" & knime.in$"Specification" == "qratio_mean"]
qratio_mean = knime.in$"Value"[knime.in$"Parameter" == "qwork" & knime.in$"Specification" == "qratio_mean"]
qratio_sd = knime.in$"Value"[knime.in$"Parameter" == "qwork" & knime.in$"Specification" == "qratio_sd"]
qratio_min = knime.in$"Value"[knime.in$"Parameter" == "qwork" & knime.in$"Specification" == "qratio_min"]
qratio_max = knime.in$"Value"[knime.in$"Parameter" == "qwork" & knime.in$"Specification" == "qratio_max"]
qwork_bw_cor = knime.in$"Value"[knime.in$"Parameter" == "qwork" & knime.in$"Specification" == "bw_cor"]

# Multivariante truncated normaldistribution
order = c("bh", "bw", "qrest", "qwork")
dists = c(as.character(bh_dist), as.character(bw_dist), as.character(qrest_dist), as.character(qwork_dist))

means = c(bh_mean, bw_mean, qrest_mean, qratio_mean)
sds = c(bh_sd, bw_sd, qrest_sd, qratio_sd)
lower = c(bh_min, bw_min, qrest_min, qratio_min)
upper = c(bh_max, bw_max, qrest_max, qratio_max)

sd_matrix = diag(sds)
cor_matrix = matrix( c(	1.0, bh_bw_cor, bh_qrest_cor, bh_qwork_cor,
                        bh_bw_cor, 1.0, qrest_bw_cor, qwork_bw_cor, 
                        bh_qrest_cor, qrest_bw_cor, 1.0, qrest_qwork_cor, 
                        bh_qwork_cor, qwork_bw_cor, qrest_qwork_cor, 1.0), ncol = 4, byrow = TRUE)

sigma = sd_matrix%*%cor_matrix%*%sd_matrix

population = rtmvnorm(n = popsize, mean = means, 
                      sigma = sigma,
                      lower = lower, 
                      upper = upper)

knime.out <- as.data.frame(population)
knime.out[,4] = knime.out[,3]*knime.out[,4]
names = c(paste(gsub("normal", "", dists[1]), "(", order[1], ")", sep =""),
          paste(gsub("normal", "", dists[2]), "(", order[2], ")", sep =""),
          paste(gsub("normal", "", dists[3]), "(", order[3], ")", sep =""),
          paste(gsub("normal", "", dists[4]), "(", order[4], ")", sep =""))
knime.out = transform(knime.out, "Gender" = unique(knime.in$"Gender"))
colnames(knime.out) = c(names, "Gender")

