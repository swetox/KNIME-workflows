library(reshape2)

colnames(knime.in) = c("Parameter", "n", "Shapiro p-value", "mean", "min", "max", "sd")
knime.in = transform(knime.in, "Source" = gsub("[A-Za-z]*_", "", knime.in$"Parameter"))
knime.in = transform(knime.in, "Distribution" = gsub("L", "l", gsub("PC[a-z]*_[A-Z0-9]*", "10normal", knime.in$"Parameter")))
knime.in = transform(knime.in, "Parameter" = gsub("_[A-Z0-9]*", "", gsub("Log", "", knime.in$"Parameter")))

knime.out = melt(knime.in, id.vars = c("Parameter", "Source", "Distribution"), measure.vars =c("mean", "min", "max", "sd"), value.name = "Value", variable.name = "Specification")


