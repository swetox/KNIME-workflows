library(msm)
sub = knime.in[,c("Specification", "Value")]

mean = sub$Value[sub$Specification == "mean"]
min = sub$Value[sub$Specification == "min"]
max = sub$Value[sub$Specification == "max"]
sd = sub$Value[sub$Specification == "sd"]
n = knime.flow.in[["n"]]

# samling a truncated normal distribution
sample = rtnorm(n, mean = mean, sd = sd, lower = min, upper = max)

colname = paste(gsub("normal", "", knime.flow.in[["Distribution"]]), "(", knime.flow.in[["Parameter"]],")", sep ="")
knime.out <- data.frame("Parameter" = sample)
colnames(knime.out) = colname