pclabels = paste("PC", knime.in$"Tissue", sep ="")
values = knime.in$"PC value"

knime.out <- as.data.frame(values)
rownames(knime.out) = pclabels