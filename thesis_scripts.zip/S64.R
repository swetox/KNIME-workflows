
knime.out <- exp(knime.in[,1:(ncol(knime.in)-1)])
colnames(knime.out) = gsub("[(]", "", gsub(")", "", gsub("log", "", colnames(knime.out))))

# bh to meters
knime.out = transform(knime.out, bh = knime.out$bh/100)
