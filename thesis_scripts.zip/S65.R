####### Parameters needed for PBTK #################


knime.out <- data.frame(
  "solvingmethod" 		= "lsoda",
  "Ventilation work" 		= knime.in$"qwork",
  "Ventilation rest"		= knime.in$"qrest",
  "Molar volume"			= knime.flow.in[["Molecular weight"]],
  "Exposure level"		= knime.flow.in[["Average Exposure"]],
  "Body height" 			= knime.in$"bh",
  "Body weight"			= knime.in$"bw",
  "CLi"				= knime.flow.in[["Clearance"]],
  "PCblood"				= knime.flow.in[["PCblood"]],
  "PCfat"				= knime.flow.in[["PCfat"]],
  "PClung"				= knime.flow.in[["PClung"]],
  "PCmuscle"			= knime.flow.in[["PCmuscle"]],
  "PCliver"				= knime.flow.in[["PCliver"]],
  "PCvessel"			=knime.flow.in[["PCvessel"]]
)

colnames(knime.out) <- c("solvingmethod", "Ventilation work", "Ventilation rest", "Molar volume", "Exposure level", "Body height", "Body weight", "CLi", "PCblood", "PCfat", "PClung", "PCmuscle", "PCliver", "PCvessel")
