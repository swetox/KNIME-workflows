library(MESS)

########## Subsets #################
dblood <- subset(knime.in, Compartment == "Cmixven")
dair <- subset(knime.in, Compartment == "Cexh")

lm_blood <- lm(log(Concentration) ~ time, subset(dblood, time>210 & time<360))
lm_air <- lm(log(Concentration) ~ time, subset(dair, time>210 & time<360))

r2_blood <- summary(lm_blood)$r.squared
r2_air <- summary(lm_air)$r.squared

########## Calculating endpoints #################
cmax_blood = max(dblood$Concentration)
thalf_blood	= log(2)/-summary(lm_blood)$coefficients[2]
auc_blood = auc(dblood$time,dblood$Concentration, type='linear')

cmax_air 	= max(dair$Concentration)
thalf_air	= log(2)/-summary(lm_air)$coefficients[2]
auc_air	= auc(dair$time,dair$Concentration, type='linear')

########## Going out ##############################
knime.out <- data.frame(	cmax_blood,
                         thalf_blood, 
                         auc_blood,
                         cmax_air,
                         thalf_air, 
                         auc_air,
                         r2_blood, 
                         r2_air)

colnames(knime.out) <- c("C[max] blood", 
                         "half time[210<t<360] blood", 
                         "AUC[tlast] blood", 
                         "C[max] air",
                         "half time[210<t<360] air",
                         "AUC[tlast] air",
                         "R^2 blood",
                         "R^2 air")
