
knime.out <- 10^(knime.in)
colnames(knime.out) = gsub("[(]", "", gsub(")", "", gsub("log10", "", colnames(knime.in))))