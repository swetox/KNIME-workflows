
low_cmax_blood = match(min(knime.in$"C[max] blood"), knime.in$"C[max] blood")
low_cmax_air = match(min(knime.in$"C[max] air"), knime.in$"C[max] air")
high_cmax_blood = match(max(knime.in$"C[max] blood"), knime.in$"C[max] blood")
high_cmax_air = match(max(knime.in$"C[max] air"), knime.in$"C[max] air")

low_auc_blood = match(min(knime.in$"AUC[tlast] blood"), knime.in$"AUC[tlast] blood")
low_auc_air = match(min(knime.in$"AUC[tlast] air"), knime.in$"AUC[tlast] air")
high_auc_blood = match(max(knime.in$"AUC[tlast] blood"), knime.in$"AUC[tlast] blood")
high_auc_air = match(max(knime.in$"AUC[tlast] air"), knime.in$"AUC[tlast] air")

low_thalf_blood = match(min(knime.in$"half time[210<t<360] blood"), knime.in$"half time[210<t<360] blood")
low_thalf_air = match(min(knime.in$"half time[210<t<360] air"), knime.in$"half time[210<t<360] air")
high_thalf_blood = match(max(knime.in$"half time[210<t<360] blood"), knime.in$"half time[210<t<360] blood")
high_thalf_air = match(max(knime.in$"half time[210<t<360] air"), knime.in$"half time[210<t<360] air")

index = c(low_cmax_blood, 
          low_cmax_air,
          high_cmax_blood,
          high_cmax_air,
          low_auc_blood, 
          low_auc_air,
          high_auc_blood,
          high_auc_air,
          low_thalf_blood, 
          low_thalf_air,
          high_thalf_blood,
          high_thalf_air)

measures = c(	"lowest C[max] blood", "lowest C[max] air",
              "highest C[max] blood", "highest C[max] air", 
              "lowest AUC[tlast] blood", "lowest AUC[tlast] air",
              "highest AUC[tlast] blood", "highest AUC[tlast] air", 
              "lowest half time[210<t<360] blood", "lowest half time[210<t<360] air",
              "highest half time[210<t<360] blood", "highest half time[210<t<360] air")

knime.out <- knime.in[index,]
knime.out$extremes = measures
knime.out$setup = paste(knime.flow.in[["Compound"]], ",", knime.flow.in[["Gender"]], ",", knime.flow.in[["Exposure level"]], sep="")
knime.out$Source = knime.flow.in[["Source"]]