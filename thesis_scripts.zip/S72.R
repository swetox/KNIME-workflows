knime.out <- knime.in
knime.out$setup = paste(knime.flow.in[["Compound"]], ",", knime.flow.in[["Gender"]], ",", knime.flow.in[["Exposure level"]], sep="")