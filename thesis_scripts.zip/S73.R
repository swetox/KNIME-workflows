library(reshape2)

df_plot = knime.in
colnames = colnames(knime.in)
df_plot = melt(knime.in, id.vars = colnames[9:ncol(df_plot)], measure.vars = colnames[1:6], value.name = "endpointvalue", variable.name = "endpointtissue")
df_plot = melt(df_plot, id.vars = c("endpointvalue", "endpointtissue"), value.name = "parametervalue", variable.name = "parameter")
df_plot = cbind(df_plot, data.frame(do.call('rbind', strsplit(as.character(df_plot$endpointtissue),'] ',fixed=TRUE))))
names(df_plot)[names(df_plot) == "X1"] = "endpoint"
names(df_plot)[names(df_plot) == "X2"] = "tissue"
df_plot = transform(df_plot, "endpoint" = paste(df_plot$endpoint, "]", sep =""))
df_plot = transform(df_plot, "endpointtissue" = gsub("half time", "halftime", df_plot$endpointtissue))
df_plot = transform(df_plot, "group" = paste(df_plot$endpointtissue, df_plot$parameter))

c = by(df_plot, df_plot$group, FUN = function(x) cor.test(x$parametervalue, x$endpointvalue, method = "spearman")$estimate)
t = by(df_plot, df_plot$group, FUN = function(x) cor.test(x$parametervalue, x$endpointvalue, method = "spearman")$p.value)

res_spearman = data.frame(group = attributes(c)$dimnames[[1]], 
                          corr = as.numeric(c), 
                          pvalue = as.numeric(t), 
                          row.names = NULL)

info = data.frame(do.call('rbind', strsplit(as.character(res_spearman$group),' ',fixed=TRUE)))
info[,1]

colnames(info) = c("endpoint", "tissue", "parameter")
info$setup = paste(knime.flow.in[["Compound"]], ",", knime.flow.in[["Gender"]], ",", knime.flow.in[["Exposure level"]], sep="")

knime.out = cbind(res_spearman, info)