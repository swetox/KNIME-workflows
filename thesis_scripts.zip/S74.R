knime.out = subset(knime.in, knime.in$"pvalue" < 0.05)

if(nrow(knime.out) > 1){
  i = match(max(abs(knime.out$corr)), abs(knime.out$corr))
  knime.out = knime.out[i,]
} else if(nrow(knime.out) == 0){
  i = match(max(abs(knime.in$corr)), abs(knime.in$corr))
  knime.out = knime.in[i,]
}
