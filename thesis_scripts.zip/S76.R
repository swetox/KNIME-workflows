knime.out = knime.in[,9:ncol(knime.in)]
knime.out = transform(knime.out, "log(bh)" = exp(knime.out$"log(bh)")/100)
knime.out = transform(knime.out, "log.bw." = exp(knime.out$"log.bw."))
knime.out = transform(knime.out, "log.qrest." = exp(knime.out$"log.qrest."))
knime.out = transform(knime.out, "log.qwork." = exp(knime.out$"log.qwork."))

colnames(knime.out) = c("bh", "bw", "qrest", "qwork", "Gender", "extremes", "setup", "Source")