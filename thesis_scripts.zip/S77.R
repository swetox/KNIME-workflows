
resultfolder = gsub("workspace", "results", knime.flow.in[["knime.workspace"]])

knime.out <- knime.in
knime.out$Modelfilepath = paste(resultfolder, "//",knime.in$"Generation", "models//", knime.in$"Modelfile", sep ="")