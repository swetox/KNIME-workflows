extremes = unlist(strsplit(knime.flow.in[["extremes"]], " "))
tissue = extremes[length(extremes)]
extreme = extremes[1]
compartment = ifelse(tissue == "air", "Cexh", "Cmixven")
knime.out = data.frame(	"Tissue" = extremes[length(extremes)],
                        "Compartment" = compartment,
                        "Extreme" = extreme)