label = gsub(paste(knime.flow.in[["Extreme"]], " ", sep =""),"", gsub(paste(" ", knime.flow.in[["Tissue"]], sep= ""), "", knime.flow.in[["extremes"]]))
knime.out <- knime.in

tissuelist <- c()
for(i in 1:nrow(knime.in)){
  comp = knime.in$"Compartment"[i]
  if(comp == "Cmixven"){
    tissuelist[i] = "Blood"
  } else {
    tissuelist[i] = "Exhaled air"
  }
}
knime.out$Tissue = tissuelist

knime.out$"Extreme" <- knime.flow.in[["Extreme"]]
knime.out$"Label" <- label
