knime.out <- knime.in

tissuelist <- c()
for(i in 1:nrow(knime.in)){
  comp = knime.in$"Compartment"[i]
  if(comp == "Cmixven"){
    tissuelist[i] = "Blood"
  } else {
    tissuelist[i] = "Exhaled air"
  }
}
knime.out$Tissue = tissuelist
knime.out$Extreme = "mean"
knime.out$Label = "PBTK"
