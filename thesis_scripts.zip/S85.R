knime.out <- knime.in
colnames(knime.out) = c("time", "Concentration", "Minimum", "Maximum", "Tissue")

compartmentlist <- c()
for(i in 1:nrow(knime.out)){
  comp = knime.out$"Tissue"[i]
  if(comp == "Blood"){
    compartmentlist[i] = "Cmixven"
  } else {
    compartmentlist[i] = "Cexh"
  }
}
knime.out$Compartment = compartmentlist
knime.out$Label <- "in vivo"