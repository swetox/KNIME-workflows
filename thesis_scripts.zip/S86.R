##########################################

d_air_ex <- subset(knime.in, (Compartment == "Cexh" & Label == "in vivo"))
d_blood_ex <- subset(knime.in, (Compartment == "Cmixven" & Label == "in vivo"))
d_air_pbtk <- subset(knime.in, (Compartment == "Cexh" & Label == "PBTK"))
d_blood_pbtk <- subset(knime.in, (Compartment == "Cmixven" & Label == "PBTK"))

############################################

time_air_ex <- as.character(unique(d_air_ex$time))
time_blood_ex <- as.character(unique(d_blood_ex$time))

time_air_pbtk <- as.character(unique(d_air_pbtk$time))
time_blood_pbtk <- as.character(unique(d_blood_pbtk$time))

############## Filter ########################
nair <- which(time_air_pbtk %in% time_air_ex)
nblood <- which(time_blood_pbtk %in% time_blood_ex)

############# Going out ##########################
knime.out <- rbind(d_air_ex[,c(1:3,6)], d_blood_ex[,c(1:3,6)], d_air_pbtk[nair,c(1:3,6)], d_blood_pbtk[nblood,c(1:3, 6)])