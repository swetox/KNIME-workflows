library(MESS)
######### Comparison of PBPK and experimental data #########
######## Subsets #############

d_air_ex <- subset(knime.in, (Compartment == "Cexh" & Label == "in vivo"))
d_blood_ex <- subset(knime.in, (Compartment == "Cmixven" & Label == "in vivo"))
d_air_pbtk <- subset(knime.in, (Compartment == "Cexh" & Label == "PBTK"))
d_blood_pbtk <- subset(knime.in, (Compartment == "Cmixven" & Label == "PBTK"))

# auc analysis
auc_blood_ex 		<- auc(d_blood_ex$time,d_blood_ex$Concentration,  type='linear')
auc_air_ex		<- auc(d_air_ex$time, d_air_ex$Concentration,  type='linear')
auc_blood_pbtk 	<- auc(d_blood_pbtk$time, d_blood_pbtk$Concentration,  type='linear')
auc_air_pbtk 		<- auc(d_air_pbtk$time, d_air_pbtk$Concentration,  type='linear')

# cmax analysis
cmax_blood_ex 		<- max(d_blood_ex$Concentration)
cmax_air_ex		<- max(d_air_ex$Concentration)
cmax_blood_pbtk 	<- max(d_blood_pbtk$Concentration)
cmax_air_pbtk 		<- max(d_air_pbtk$Concentration)

# Halflife
lm_blood_ex		= lm(log(Concentration) ~ time, d_blood_ex[(nrow(d_blood_ex)-3):nrow(d_blood_ex),])
lm_air_ex			= lm(log(Concentration) ~ time, d_air_ex[(nrow(d_air_ex)-3):nrow(d_air_ex),])
lm_blood_pbtk		= lm(log(Concentration) ~ time, d_blood_pbtk[(nrow(d_blood_pbtk)-3):nrow(d_blood_pbtk),])
lm_air_pbtk		= lm(log(Concentration) ~ time, d_air_pbtk[(nrow(d_air_pbtk)-3):nrow(d_air_pbtk),])

thalf_blood_ex		= log(2)/-summary(lm_blood_ex)$coefficients[2]
thalf_air_ex		= log(2)/-summary(lm_air_ex)$coefficients[2]
thalf_blood_pbtk	= log(2)/-summary(lm_blood_pbtk)$coefficients[2]
thalf_air_pbtk		= log(2)/-summary(lm_air_pbtk)$coefficients[2]

r2_blood_ex		= summary(lm_blood_ex)$r.squared
r2_air_ex			= summary(lm_air_ex)$r.squared
r2_blood_pbtk		= summary(lm_blood_pbtk)$r.squared
r2_air_pbtk		= summary(lm_air_pbtk)$r.squared

# RMSE 
RMS_blood_ex 		= sqrt(mean(d_blood_ex$Concentration^2))
RMS_air_ex 		= sqrt(mean(d_air_ex$Concentration^2))

RMSE_blood		= sqrt(mean((d_blood_pbtk$Concentration-d_blood_ex$Concentration)^2))
RMSE_air			= sqrt(mean((d_air_pbtk$Concentration-d_air_ex$Concentration)^2))

# N timepoints
nblood 			= length(d_blood_ex$time)
nair 			= length(d_air_ex$time)

# Index 			
Index_blood		= RMSE_blood/RMS_blood_ex
Index_air			= RMSE_air/RMS_air_ex
Index_total 		= Index_blood*(nblood/(nblood+nair))+Index_air*(nair/(nblood+nair))

######### Dataframe  ########################################
dataframe 						<- data.frame("Setup" = rep(knime.flow.in[["Setup"]], 4))
dataframe$"Source"					<- knime.flow.in[["Source"]]
dataframe$"Compartment"				<- c("Blood", "Blood", "Exhaled air", "Exhaled air")
dataframe$"Data"					<- c("PBTK", "in vivo", "PBTK", "in vivo")

dataframe$"AUC"					<- c(auc_blood_pbtk,
                         auc_blood_ex,
                         auc_air_pbtk,
                         auc_air_ex)
dataframe$"AUCratio"				<- c(auc_blood_pbtk/auc_blood_ex, NA,
                             auc_air_pbtk/auc_air_ex, NA)
dataframe$"Cmax"					<- c(cmax_blood_pbtk,
                          cmax_blood_ex,
                          cmax_air_pbtk,
                          cmax_air_ex)
dataframe$"Cmaxratio"				<- c(cmax_blood_pbtk/cmax_blood_ex, NA,
                              cmax_air_pbtk/cmax_air_ex, NA)

dataframe$"t_half"					<- c(thalf_blood_pbtk,
                            thalf_blood_ex,
                            thalf_air_pbtk,
                            thalf_air_ex)
dataframe$"t_halfRatio"				<- c(thalf_blood_pbtk/thalf_blood_ex, NA,
                                thalf_air_pbtk/thalf_air_ex, NA)
dataframe$"R2_elimination"			<- c(r2_blood_pbtk,
                                  r2_blood_ex,
                                  r2_air_pbtk,
                                  r2_air_ex)
dataframe$"RMSE"					<- c(RMSE_blood, NA, RMSE_air, NA)
dataframe$"Index"					<- c(Index_blood, NA, Index_air, NA)
dataframe$"Index total"				<- Index_total

####### Going out ########################################
knime.out <- dataframe
