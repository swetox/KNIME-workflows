###############################
########## Libraries ###########
library(ggplot2)
library(grid)

mytheme = base_size = 14
mytheme <- theme(
  text =					element_text(family = "Arial"),			
  title =					element_text(family = "Arial"),			
  
  axis.line =         	element_line(colour = "black"),
  axis.text.x =       	element_text(size = base_size * 0.7 , face = "bold", lineheight = 0.9, colour = "black", vjust = 1),
  axis.text.y =       	element_text(size = base_size * 0.7, face = "bold", lineheight = 0.9, colour = "black", hjust = 1),
  axis.ticks =        	element_line(colour = "black", size = 0.3),
  axis.title.x =      	element_text(size = base_size*0.9, face = "bold", vjust = 0.5),
  axis.title.y =      	element_text(size = base_size*0.9, face = "bold", angle = 90, vjust = 0.5),
  axis.ticks.length = 	unit(0.1, "cm"),
  axis.ticks.margin = 	unit(0.1, "cm"),
  
  legend.background = element_rect(colour=NA), 
  legend.key =        element_rect(fill = NA, colour = "black", size = 0.5),
  legend.key.size =   unit(1.2, "lines"),
  legend.text =       element_text(size = base_size * 0.7),
  legend.title =      element_text(size = base_size * 0.7, face = "bold", hjust = 0),
  legend.position =   "bottom",
  
  panel.background =  element_rect(fill = NA, colour = NA, size = 0.25), 
  panel.border =      element_blank(),
  panel.grid.major =  element_line(colour = NA, size = 0.05),
  panel.grid.minor =  element_line(colour = NA, size = 0.05),
  panel.margin =      unit(0.25, "lines"),
  
  strip.background =  element_rect(fill = NA, colour = NA), 
  strip.text.x =      element_text(colour = "black", face = "bold", size = base_size*0.7),
  strip.text.y =      element_text(colour = "black", face = "bold", size = base_size*0.7, angle = -90),
  
  plot.background =   element_rect(colour = NA, fill = "white"),
  plot.title =        element_text(size = base_size*0.9, face = "bold", vjust  = 0.5, hjust = 0.5),
  plot.margin =       unit(c(1, 1, 0.5, 0.5), "lines")
)

########### Splitting in two dataframes ###########
df_plot = knime.in
df_plot = transform(df_plot, "Label" = gsub("210<t<360", "", df_plot$Label)) #bold(210\u003c~t\u003c~360)
df_plot = transform(df_plot, "Label" = gsub("half time\\[\\]", "half~time", df_plot$Label))
df_plot = transform(df_plot, "Label" = gsub("AUC\\[tlast\\]", "AUC\\['0-6h'\\]", df_plot$Label))
df_plot = transform(df_plot, "Label" = gsub("C\\[max\\]", "C\\['max'\\]", df_plot$Label))
df_plot = transform(df_plot, "Label" = gsub("in vivo", "in~vivo", df_plot$Label))

df1 <- subset(df_plot, (Label != "in~vivo"))
df2 <- subset(df_plot, Label == "in~vivo")

########### Labels #################################

xlab = "Time (min)"
ylab = "Concentration (\u03BCM)"
scenario = gsub(",", ", ", knime.flow.in[["Scenario"]])
title = paste(scenario, " ppm", sep = "")
#######################################################



p = ggplot(df1, aes(x = time, y = Concentration)) + mytheme +
  geom_line(aes(linetype = Label, colour = tissue_label, size = Extreme)) +
  geom_point(data = df2, aes(shape = Tissue), cex = 2, colour="grey20") +
  geom_errorbar(data = df2, width = 4, aes(x = time, ymin = Minimum, ymax = Maximum), alpha = 0.8,  colour="grey20") +
  labs(x = xlab, y = ylab, title = title) +
  scale_linetype_manual(values = c(2, 3, 4, 1), labels = unlist(lapply(unique(df1$Label)[c(3,2,4,1)], function(x) {parse(text=x)}))) +
  scale_size_manual(values = c(0.3, 0.3, 0.6)) + 
  scale_shape_manual(values = c(16, 16)) +
  scale_colour_manual(values = c("red", "blue","grey50", "grey50", "grey50", "grey50", "grey50", "grey50","darkred", "darkblue")) + 
  scale_y_continuous(trans = "log10", expand = c(0.01,0.04), breaks = c(0.0001, 0.001, 0.01, 0.1, 1.0, 10, 100, 1000), labels= c(format(0.0001, scientific = FALSE), 0.001, 0.01, 0.1, 1.0, 10, 100, 1000), limits = c(0.0001, NA))+
  scale_x_continuous(expand = c(0,0)) + 
  annotation_logticks(sides = "l", base = 12, color = "black", short = unit(0.03, "cm"), mid= unit(0.03, "cm"), long = unit(0.04, "cm") )+
  facet_wrap(~Tissue, ncol = 1) +
  guides(size = "none", shape = "none", colour ="none") + #linetype = "none
  theme(legend.position = "top",
        legend.title = element_blank(),
        strip.background = element_blank(), 
        strip.text.x = element_blank())

p

ymax = layer_scales(p)$y$range$range[2]
xmax = layer_scales(p)$x$range$range[2]

facet_text = data.frame(label = c("Blood", "Exhaled air"), Tissue = c("Blood", "Exhaled air"), x = xmax-xmax*0.05, y = 10^ymax-10^(ymax*0.5))
p = p + geom_text(data = facet_text, aes(x = x, y = y, label = label), hjust = 1, vjust = 1, size = 8, fontface = "bold")
p
