######## Generating correct folder names #############
###### For folders located in KNIME folder ########

#### All workflows should be located 
#### in "workspace" in the folder KNIME

####### Computer specific settings #########
####### Fixing correct babel #################
macbabel 		= "/usr/local/bin/babel"
windowsbabel 	= "/C:/Program Files/KNIME/plugins/org.knime.ext.chem.openbabel.bin.win32.x86_2.3.1.v201701191301/win32/x86/babel.exe"

computer = Sys.info()[["sysname"]]

if(computer == "Darwin"){
  babelstring = macbabel
  sepo = "/"
} else {
  babelstring = windowsbabel
  sepo = "\\"
}

#######################################

# Base folder:
basefolder = gsub("workspace","", knime.flow.in[["knime.workspace"]])

###### headfolders Data and results #####
datafolder 	= paste(basefolder, "data", sepo, sep = "")
resultsfolder 	= paste(basefolder, "results", sepo, sep ="")


knime.out <- data.frame(
  ##### Specific folders ###################
  editedfolder		= paste(datafolder, "edited", sepo, sep =""),
  infofolder 		= paste(resultsfolder, "info", sepo, sep =""),
  
  ##### Specific files ####################
  datasubsetname			= "Data_subsetlist",
  modelselectionname		= "ModelSelection",
  optimizationdescriptorsname = "OptimizationDescriptors",
  
  ######## Others ########################
  datasheet_default = "All subsets",
  modellistsheet_default = "SelectionGeneral",
  "babelstring" = babelstring
)

