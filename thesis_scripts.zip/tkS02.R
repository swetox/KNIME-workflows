exists = file.exists(knime.flow.in[["ModelSelection_default"]])

if(exists==TRUE){
  knime.out <- data.frame("exists" = "TRUE")
} else{
  knime.out <- data.frame("exists" = "FALSE")
}
