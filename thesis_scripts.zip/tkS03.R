############# Log or untransformed ##########
nc = match(knime.flow.in[["PC"]], colnames(knime.in))

knime.out <- knime.in

if(knime.flow.in[["transformation"]] == "Log10"){
  knime.out[,nc]		= 10^knime.out[,nc]
} else if(knime.flow.in[["transformation"]]=="Log"){
  knime.out[,nc]		= exp^knime.out[,nc]
  
}
