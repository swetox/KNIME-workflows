########## Any extreme values ? ###################
col = grep("PC", colnames(knime.in))

if(any(knime.in[,col] <0 | knime.in[,col] > 50000)){
  indicator = "Too extreme"
} else {
  indicator = "OK"
}

knime.out <- data.frame(indicator)

