############################

knime.out <- knime.in[,c(1,2,4)]
colnames(knime.out)[3] <- "Prediction"
knime.out$"PC" = colnames(knime.in)[4]