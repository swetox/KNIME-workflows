
resultfolder = gsub("workspace", "models", knime.flow.in[["knime.workspace"]])

knime.out <- knime.in
knime.out$Modelfilepath = paste(resultfolder, "//",knime.in$"Modelfile", sep ="")